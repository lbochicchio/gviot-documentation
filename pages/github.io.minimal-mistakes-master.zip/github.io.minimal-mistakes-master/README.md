GV IoT Platform documentation.

This is the repository for the GV IoT Platform documentation and contains the source content for the link: https://greenvulcano.github.io/gviot-documentation/
